from string import punctuation

with open("files/text.txt", "r") as file:
    text = file.readlines()

output = open("files/output.txt")

for x in range(len(text)):
    letter, mark = 0, 0

    for symbol in text[x]:
        if symbol.isalpha():
            letter += 1

        elif symbol in punctuation:
            mark += 1

    output.write(f"Line {x + 1}: {''.join(text[x][::-1])} ({letter}) ({mark})")

output.close()

